#!/bin/bash
set -e

FOLDER="dsmp-full-template"

# Bersihkan
rm -rf "$FOLDER" dsmp-full-template.zip

# Buat struktur
mkdir -p "$FOLDER"/{backend/{controllers,routes},frontend/{src/components,public},simulator,docs,.github/workflows}

# env.sample 📋
cat << 'EOF' > "$FOLDER"/.env.sample
PORT=3000
JWT_SECRET=your_jwt_secret
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=root
DB_NAME=dsmp
MQTT_BROKER=mqtt://localhost
MQTT_USER=mqttuser
MQTT_PASS=mqttpassword
SLACK_WEBHOOK=https://hooks.slack.com/services/XXX/YYY/ZZZ
AWS_ACCESS_KEY_ID=your_key
AWS_SECRET_ACCESS_KEY=your_secret
S3_BUCKET=dsmp-report
EOF

# README.md
cat << 'EOF' > "$FOLDER"/README.md
# DSMP — DSTech Smart Management Parkir

📌 Panduan:
- Backend API dengan entry/exit webhook
- Frontend React: EntryForm, ExitForm, Dashboard
- Simulator NFC + MQTT gate
- CI/CD via GitHub Actions (unit, E2E, coverage, deploy)
- Monitoring: Prometheus/Elasticsearch + Grafana
- Dokumentasi Markdown & PDF
EOF

# docker-compose.yml
cat << 'EOF' > "$FOLDER"/docker-compose.yml
version: '3'
services:
  backend:
    build: ./backend
    ports: ["3000:3000"]
    env_file: .env.sample
  frontend:
    build: ./frontend
    ports: ["3001:3001"]
  mqtt:
    image: eclipse-mosquitto
    ports: ["1883:1883"]
EOF

# Backend boilerplate
cat << 'EOF' > "$FOLDER"/backend/package.json
{ "name":"backend", "version":"1.0.0", "main":"index.js", "scripts":{ "start":"node index.js" }, "dependencies":{ "express":"^4.18.2","dotenv":"^16.0.0","mysql2":"^3.1.0","knex":"^2.4.0","mqtt":"^4.3.7","socket.io":"^4.9.0","prom-client":"^14.0.1","cors":"^2.8.5","bcrypt":"^5.1.0","jsonwebtoken":"^9.0.0" } }
EOF

cat << 'EOF' > "$FOLDER"/backend/index.js
require('dotenv').config();
const express= require('express');
const cors= require('cors');
const { entryRouter, exitRouter } = require('./routes/parkingRoutes');
const { sendMetrics } = require('./metrics');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
app.use(cors(), express.json());
app.use('/api/entry', entryRouter);
app.use('/api/exit', exitRouter);
app.get('/api/health', (req, res) => res.json({status: 'ok'}));
app.get('/metrics', sendMetrics);

const server = http.createServer(app);
const io = socketIo(server, { cors: { origin: "*" } });
io.on('connection', () => console.log('👤 WS connected'));

server.listen(process.env.PORT||3000, ()=> console.log('Backend running'));
EOF

cat << 'EOF' > "$FOLDER"/backend/routes/parkingRoutes.js
const express = require('express');
const controller = require('../controllers/parkingController');
const routerEntry = express.Router();
const routerExit = express.Router();
routerEntry.post('/', controller.entry);
routerExit.post('/', controller.exit);
module.exports = { entryRouter: routerEntry, exitRouter: routerExit };
EOF

cat << 'EOF' > "$FOLDER"/backend/controllers/parkingController.js
const knex = require('knex')({
  client: 'mysql2',
  connection: {
    host:process.env.DB_HOST,
    user:process.env.DB_USER,
    password:process.env.DB_PASSWORD,
    database:process.env.DB_NAME
  }
});
const mqtt = require('mqtt');
const client = mqtt.connect(process.env.MQTT_BROKER, {
  username:process.env.MQTT_USER,
  password:process.env.MQTT_PASS
});

exports.entry = async (req,res) => {
  const { card_uid, type } = req.body;
  const [id] = await knex('visitors').insert({ card_uid, type });
  client.publish('dsmp/gate/open', JSON.stringify({id,type}));
  res.json({message:'Gate Open', id});
}

exports.exit = async (req,res) => {
  const { id } = req.body;
  const visitor = await knex('visitors').where({id}).first();
  const now = new Date();
  const fee = ((now - visitor.entry_time)/3600000) * 5000;
  await knex('visitors').where({id}).update({exit_time:now, fee});
  client.publish('dsmp/gate/open', JSON.stringify({id,type:visitor.type}));
  res.json({message:'Exit OK', fee, id});
}
EOF

cat << 'EOF' > "$FOLDER"/backend/metrics.js
const client = require('prom-client');
client.collectDefaultMetrics();
module.exports.sendMetrics = async (req, res) => {
  res.set('Content-Type', client.register.contentType);
  res.end(await client.register.metrics());
}
EOF

# Frontend boilerplate
cat << 'EOF' > "$FOLDER"/frontend/package.json
{ "name":"frontend","version":"1.0.0","private":true,"dependencies":{},"scripts":{"start":"react-scripts start","build":"react-scripts build"} }
EOF

cat << 'EOF' > "$FOLDER"/frontend/src/components/EntryForm.js
import React, { useState } from 'react';
import axios from 'axios';
export default function EntryForm(){
  const [card,setCard]=useState('');
  const [type,setType]=useState('emoney');
  const [msg,setMsg]=useState('');
  const send = async ()=>{ const r=await axios.post('http://localhost:3000/api/entry',{card_uid:card,type}); setMsg(JSON.stringify(r.data)); }
  return (<div><h3>Entry</h3><input value={card} onChange={e=>setCard(e.target.value)}/><select value={type} onChange={e=>setType(e.target.value)}><option>emoney</option><option>member</option><option>tiket</option></select><button onClick={send}>Go</button><pre>{msg}</pre></div>);
}
EOF

cat << 'EOF' > "$FOLDER"/frontend/src/components/ExitForm.js
import React,{useState} from 'react';
import axios from 'axios';
export default function ExitForm(){
  const [id,setId]=useState(''); const [msg,setMsg]=useState('');
  const send=async()=>{ const r=await axios.post('http://localhost:3000/api/exit',{id}); setMsg(JSON.stringify(r.data)); };
  return (<div><h3>Exit</h3><input value={id} onChange={e=>setId(e.target.value)}/><button onClick={send}>Go</button><pre>{msg}</pre></div>);
}
EOF

cat << 'EOF' > "$FOLDER"/frontend/src/index.js
import React from 'react';
import ReactDOM from 'react-dom';
import EntryForm from './components/EntryForm';
import ExitForm from './components/ExitForm';
ReactDOM.render(<div><EntryForm/><ExitForm/></div>, document.getElementById('root'));
EOF

cat << 'EOF' > "$FOLDER"/frontend/public/index.html
<!DOCTYPE html><html><head><meta charset="utf-8" /><title>DSMP Frontend</title></head><body><div id="root"></div></body></html>
EOF

# Simulator
cat << 'EOF' > "$FOLDER"/simulator/sim-nfc.js
const axios = require('axios');
setInterval(async()=>{
  const r=await axios.post('http://localhost:3000/api/entry',{card_uid:'SIM-NFC',type:'emoney'});
  console.log(r.data);
},15000);
EOF

# Docs
cat << 'EOF' > "$FOLDER"/docs/DSMP_Documentation.md
# DSMP Documentation

Silakan lengkapi dokumentasi di sini.
EOF

# CI/CD advanced
cat << 'EOF' > "$FOLDER"/.github/workflows/ci.yml
name: DSMP CI/CD
on: [push]

jobs:
  build:
    runs-on: ubuntu-latest
    services:
      mysql:
        image: mysql:8
        ports: ['3306:3306']
        env:
          MYSQL_ROOT_PASSWORD: root
          MYSQL_DATABASE: dsmp_test
    steps:
      - uses: actions/checkout@v3
      - run: |
          cd backend && npm install
          cd ../frontend && npm install
          cd ..
          docker-compose up -d --build
      - run: npm test --prefix backend
      - run: npm run cy:run --prefix frontend
EOF

# ZIP semua
zip -r dsmp-full-template.zip "$FOLDER"

echo "✅ ZIP lengkap siap: dsmp-full-template.zip"
